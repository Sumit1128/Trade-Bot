# ============================================================
#  order_manager.py — Order Placement & Management
# ============================================================
"""
Handles order placement for all segments.
In PAPER_TRADE mode, logs simulated orders without API calls.
In LIVE mode, places real orders via Fyers API.
"""

import json
from datetime import datetime
from typing import Optional

import config
from strategy import TradeSignal, SignalType


class OrderManager:
    def __init__(self, fyers_client):
        self.client      = fyers_client
        self.paper_trades = []   # Simulated trade log
        self.open_orders  = {}   # symbol -> order info

    # ── Place Entry Order ─────────────────────────────────
    def place_entry(self, signal: TradeSignal, trade_type: str = "intraday") -> Optional[dict]:
        """
        Place a buy (LONG) or sell-short (SHORT) entry order.
        trade_type: "intraday" | "swing" | "positional"
        """
        side = 1 if signal.signal == SignalType.LONG else -1  # 1=buy, -1=sell

        # Determine product type
        if trade_type == "intraday":
            product = "INTRADAY"
        elif trade_type in ("swing", "positional", "longterm"):
            product = "CNC"
        else:
            product = "MARGIN"

        order_payload = {
            "symbol":       signal.symbol,
            "qty":          signal.qty,
            "type":         2,           # 2 = Market Order, 1 = Limit
            "side":         side,
            "productType":  product,
            "limitPrice":   0,
            "stopPrice":    0,
            "validity":     "DAY",
            "disclosedQty": 0,
            "offlineOrder": False,
        }

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if config.PAPER_TRADE:
            return self._paper_entry(signal, order_payload, timestamp, trade_type)
        else:
            return self._live_entry(signal, order_payload, timestamp, trade_type)

    def _paper_entry(self, signal: TradeSignal, payload: dict, ts: str, trade_type: str) -> dict:
        trade_id = f"PAPER_{len(self.paper_trades)+1:04d}"
        trade = {
            "id":         trade_id,
            "symbol":     signal.symbol,
            "signal":     signal.signal.value,
            "entry":      signal.entry,
            "stop_loss":  signal.stop_loss,
            "target":     signal.target,
            "qty":        signal.qty,
            "invest":     signal.total_invest,
            "max_loss":   signal.risk * signal.qty,
            "max_profit": signal.reward * signal.qty,
            "trade_type": trade_type,
            "status":     "OPEN",
            "entry_time": ts,
            "exit":       None,
            "pnl":        None,
        }
        self.paper_trades.append(trade)
        self.open_orders[signal.symbol] = trade
        self._log(f"📝 PAPER ENTRY | {trade_id} | {signal.signal.value} {signal.symbol} "
                  f"@ ₹{signal.entry} | Qty: {signal.qty} | Invest: ₹{signal.total_invest:.0f} "
                  f"| SL: ₹{signal.stop_loss} | Target: ₹{signal.target}")
        return trade

    def _live_entry(self, signal: TradeSignal, payload: dict, ts: str, trade_type: str) -> dict:
        try:
            resp = self.client.place_order(data=payload)
            if resp.get("s") == "ok":
                order_id = resp["id"]
                self._log(f"✅ LIVE ORDER | {order_id} | {signal.signal.value} {signal.symbol} "
                          f"@ Market | Qty: {signal.qty} | SL: ₹{signal.stop_loss} | Target: ₹{signal.target}")
                # Place bracket SL order after entry
                self._place_sl_order(signal, order_id)
                return {"id": order_id, "symbol": signal.symbol, "status": "PLACED"}
            else:
                self._log(f"❌ ORDER FAILED | {signal.symbol}: {resp.get('message','')}")
                return None
        except Exception as e:
            self._log(f"❌ ORDER EXCEPTION | {signal.symbol}: {e}")
            return None

    # ── Stop-Loss Order ───────────────────────────────────
    def _place_sl_order(self, signal: TradeSignal, parent_id: str):
        """Place a SL-M order after entry fill."""
        sl_side = -1 if signal.signal == SignalType.LONG else 1  # Reverse for exit
        sl_payload = {
            "symbol":       signal.symbol,
            "qty":          signal.qty,
            "type":         3,           # 3 = SL-M
            "side":         sl_side,
            "productType":  "INTRADAY",
            "stopPrice":    signal.stop_loss,
            "limitPrice":   0,
            "validity":     "DAY",
            "disclosedQty": 0,
            "offlineOrder": False,
        }
        try:
            resp = self.client.place_order(data=sl_payload)
            if resp.get("s") == "ok":
                self._log(f"🛡️  SL ORDER placed @ ₹{signal.stop_loss} | Parent: {parent_id}")
        except Exception as e:
            self._log(f"⚠️  SL ORDER FAILED: {e}")

    # ── Exit / Square Off ─────────────────────────────────
    def exit_position(self, symbol: str, exit_price: float, reason: str = "Manual"):
        """Exit an open position (paper or live)."""
        if symbol not in self.open_orders:
            print(f"⚠️  No open order for {symbol}")
            return

        trade = self.open_orders[symbol]
        pnl   = (exit_price - trade["entry"]) * trade["qty"]
        if trade["signal"] == "SHORT":
            pnl = -pnl

        trade["status"]    = "CLOSED"
        trade["exit"]      = exit_price
        trade["pnl"]       = round(pnl, 2)
        trade["exit_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        trade["exit_reason"] = reason

        emoji = "🟢" if pnl > 0 else "🔴"
        self._log(f"{emoji} EXIT | {symbol} @ ₹{exit_price} | P&L: ₹{pnl:+.2f} | Reason: {reason}")

        del self.open_orders[symbol]

        if not config.PAPER_TRADE:
            # Live: place market exit order
            side = -1 if trade["signal"] == "LONG" else 1
            self.client.place_order(data={
                "symbol": symbol, "qty": trade["qty"],
                "type": 2, "side": side,
                "productType": "INTRADAY", "validity": "DAY",
                "disclosedQty": 0, "offlineOrder": False,
            })

    # ── Options Order ─────────────────────────────────────
    def place_options_order(self, opt_signal: dict) -> Optional[dict]:
        """Buy options (CE or PE) based on options signal dict."""
        symbol   = opt_signal.get("symbol")
        lots     = opt_signal.get("lots", 1)
        lot_size = opt_signal.get("lot_size", 1)
        qty      = lots * lot_size
        premium  = opt_signal.get("premium")

        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if config.PAPER_TRADE:
            trade = {
                "id":        f"OPT_PAPER_{len(self.paper_trades)+1:03d}",
                "symbol":    symbol,
                "type":      "OPTIONS_BUY",
                "qty":       qty,
                "premium":   premium,
                "max_loss":  opt_signal["total_cost"],
                "entry_time": ts,
                "status":    "OPEN",
            }
            self.paper_trades.append(trade)
            self._log(f"📝 OPT PAPER | {symbol} | Buy {lots} lot(s) @ ₹{premium} | Cost: ₹{opt_signal['total_cost']:.0f}")
            return trade
        else:
            resp = self.client.place_order(data={
                "symbol": symbol, "qty": qty, "type": 2,
                "side": 1, "productType": "INTRADAY", "validity": "DAY",
                "disclosedQty": 0, "offlineOrder": False,
            })
            if resp.get("s") == "ok":
                self._log(f"✅ OPT LIVE | {symbol} | {resp['id']}")
            return resp

    # ── P&L Summary ───────────────────────────────────────
    def pnl_summary(self) -> dict:
        closed = [t for t in self.paper_trades if t.get("status") == "CLOSED"]
        open_  = [t for t in self.paper_trades if t.get("status") == "OPEN"]
        total_pnl    = sum(t.get("pnl", 0) or 0 for t in closed)
        winning      = [t for t in closed if (t.get("pnl") or 0) > 0]
        losing       = [t for t in closed if (t.get("pnl") or 0) <= 0]
        win_rate     = len(winning) / len(closed) * 100 if closed else 0

        print("\n" + "=" * 50)
        print("💰  P&L SUMMARY")
        print("=" * 50)
        print(f"  Closed Trades : {len(closed)}")
        print(f"  Open Trades   : {len(open_)}")
        print(f"  Wins / Losses : {len(winning)} / {len(losing)}")
        print(f"  Win Rate      : {win_rate:.1f}%")
        print(f"  Total P&L     : ₹{total_pnl:+.2f}")
        print(f"  Capital Left  : ₹{config.TOTAL_CAPITAL + total_pnl:.2f}")
        print("=" * 50)

        return {"total_pnl": total_pnl, "win_rate": win_rate, "closed": len(closed)}

    # ── Logger ────────────────────────────────────────────
    def _log(self, msg: str):
        ts  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        out = f"[{ts}] {msg}"
        print(out)
        with open(config.LOG_FILE, "a") as f:
            f.write(out + "\n")

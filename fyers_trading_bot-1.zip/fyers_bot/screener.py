# ============================================================
#  screener.py — Multi-Segment Screener
# ============================================================
"""
Scans all watchlists (NSE, BSE, Commodities, Options) and
returns top-ranked trade signals sorted by strength score.
"""

import time
from typing import Optional

import config
from data_feed import DataFeed
from strategy import evaluate_signal, get_options_signal, TradeSignal, SignalType


class Screener:
    def __init__(self, fyers_client):
        self.feed = DataFeed(fyers_client)

    def scan_equities(
        self,
        watchlist: list[str],
        interval: str = "D",
        days: int = 60,
        segment: str = "equity"
    ) -> list[TradeSignal]:
        """Scan equity watchlist for breakout signals."""
        signals = []
        print(f"\n📊  Scanning {len(watchlist)} symbols [{segment}]...")
        for symbol in watchlist:
            df = self.feed.get_candles(symbol, interval=interval, days=days)
            signal = evaluate_signal(symbol, df, segment=segment)
            if signal:
                signals.append(signal)
            time.sleep(0.15)  # Rate limit buffer
        return signals

    def scan_commodities(self) -> list[TradeSignal]:
        """Scan MCX commodity futures for breakout signals."""
        signals = []
        print(f"\n🥇  Scanning commodities...")
        for symbol in config.COMMODITY_WATCHLIST:
            df = self.feed.get_candles(symbol, interval="D", days=60)
            signal = evaluate_signal(symbol, df, segment="commodity")
            if signal:
                signals.append(signal)
            time.sleep(0.15)
        return signals

    def scan_options(self) -> list[dict]:
        """
        For each index in OPTIONS_WATCHLIST, checks underlying trend
        and finds best options play within budget.
        """
        opt_signals = []
        print(f"\n📈  Scanning options...")
        for underlying in config.OPTIONS_WATCHLIST:
            # Get underlying trend
            sym = f"{underlying}-INDEX" if "NIFTY" in underlying else underlying
            df  = self.feed.get_candles(sym, interval="D", days=40)
            sig = evaluate_signal(sym, df, segment="options")
            if sig is None:
                continue

            chain = self.feed.get_options_chain(sym)
            opt   = get_options_signal(chain, sig.signal)
            if opt:
                opt["underlying"]    = underlying
                opt["direction"]     = sig.signal.value
                opt["underlying_sl"] = sig.stop_loss
                opt_signals.append(opt)
            time.sleep(0.3)
        return opt_signals

    def run_full_scan(self) -> dict:
        """
        Run all scans and return categorized + ranked signals.
        Returns:
          {
            "intraday":    [TradeSignal, ...],
            "swing":       [TradeSignal, ...],
            "commodity":   [TradeSignal, ...],
            "options":     [dict, ...],
            "top_picks":   [TradeSignal, ...]  # best 5 cross-segment
          }
        """
        print("=" * 60)
        print("🤖  FYERS MOMENTUM BOT — FULL MARKET SCAN")
        print("=" * 60)

        # Intraday scan (5-min candles, 10 days)
        intraday_sigs = self.scan_equities(
            config.NSE_EQUITY_WATCHLIST,
            interval=config.INTRADAY_INTERVAL,
            days=10,
            segment="intraday"
        )

        # Swing scan (daily candles, 60 days) — NSE + BSE
        swing_sigs = self.scan_equities(
            config.NSE_EQUITY_WATCHLIST + config.BSE_EQUITY_WATCHLIST,
            interval=config.SWING_INTERVAL,
            days=60,
            segment="swing"
        )

        # Commodities (daily)
        commodity_sigs = self.scan_commodities()

        # Options
        options_sigs = self.scan_options()

        # Sort by strength descending
        intraday_sigs.sort(key=lambda s: s.strength, reverse=True)
        swing_sigs.sort(key=lambda s: s.strength, reverse=True)
        commodity_sigs.sort(key=lambda s: s.strength, reverse=True)

        # Top picks: best 5 across equity + commodity
        all_equity = intraday_sigs + swing_sigs + commodity_sigs
        all_equity.sort(key=lambda s: s.strength, reverse=True)
        top_picks = all_equity[:5]

        result = {
            "intraday":  intraday_sigs[:5],
            "swing":     swing_sigs[:5],
            "commodity": commodity_sigs[:3],
            "options":   options_sigs[:3],
            "top_picks": top_picks,
        }

        self._print_summary(result)
        return result

    def _print_summary(self, result: dict):
        print("\n" + "=" * 60)
        print("📋  SCAN RESULTS SUMMARY")
        print("=" * 60)

        print(f"\n🔥  TOP PICKS (Best Signals):")
        if result["top_picks"]:
            for s in result["top_picks"]:
                print(f"\n{s}")
        else:
            print("  No strong signals found today.")

        print(f"\n⚡  INTRADAY SIGNALS ({len(result['intraday'])}):")
        for s in result["intraday"][:3]:
            print(f"  {s.signal.value:5s} {s.symbol:30s} Strength: {s.strength}/100")

        print(f"\n📅  SWING SIGNALS ({len(result['swing'])}):")
        for s in result["swing"][:3]:
            print(f"  {s.signal.value:5s} {s.symbol:30s} Strength: {s.strength}/100")

        print(f"\n🥇  COMMODITY SIGNALS ({len(result['commodity'])}):")
        for s in result["commodity"]:
            print(f"  {s.signal.value:5s} {s.symbol:30s} Strength: {s.strength}/100")

        print(f"\n📈  OPTIONS SIGNALS ({len(result['options'])}):")
        for o in result["options"]:
            print(f"  {o['direction']:5s} {o['underlying']:20s} → Buy {o['type']} | Cost: ₹{o['total_cost']}")
        print()

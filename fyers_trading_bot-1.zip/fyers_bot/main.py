# ============================================================
#  main.py — Fyers Trading Bot Orchestrator
# ============================================================
"""
Entry point for the Fyers Momentum Trading Bot.

Usage:
  python main.py                  # Full bot (scan + auto-trade)
  python main.py --scan-only      # Scan and print signals, no orders
  python main.py --mode paper     # Force paper trade mode
  python main.py --mode live      # ⚠️  Live trading (real money)

Schedule:
  - 09:20 → Morning scan + place intraday entries
  - 11:00 → Mid-morning swing/options check
  - 13:00 → Momentum re-scan
  - 15:10 → Auto square-off all intraday positions
  - 15:25 → End-of-day P&L report

Works during Indian market hours: Mon-Fri 09:15-15:30 IST
"""

import sys
import time
import argparse
from datetime import datetime, time as dtime

import schedule

import config
from auth          import get_fyers_client
from data_feed     import DataFeed
from screener      import Screener
from order_manager import OrderManager
from strategy      import SignalType


# ── Helpers ───────────────────────────────────────────────

def is_market_open() -> bool:
    now = datetime.now().time()
    return dtime(9, 15) <= now <= dtime(15, 30)

def is_intraday_window() -> bool:
    now = datetime.now().time()
    return dtime(9, 20) <= now <= dtime(15, 10)

def market_open_countdown():
    now  = datetime.now()
    open_= now.replace(hour=9, minute=15, second=0)
    if now >= open_:
        return
    secs = (open_ - now).seconds
    print(f"⏰  Market opens in {secs//3600}h {(secs%3600)//60}m {secs%60}s")
    time.sleep(min(secs, 30))


# ── Core Bot Logic ────────────────────────────────────────

class TradingBot:
    def __init__(self):
        print("\n🚀  Initialising Fyers Trading Bot...")
        self.client   = get_fyers_client()
        self.feed     = DataFeed(self.client)
        self.screener = Screener(self.client)
        self.orders   = OrderManager(self.client)
        self.daily_pnl = 0.0
        self._check_funds()

    def _check_funds(self):
        funds = self.feed.get_funds()
        if funds:
            available = funds.get("Available Balance", funds.get("Total Balance", 0))
            print(f"💳  Available Funds: ₹{available:,.2f}")
            if available < config.TOTAL_CAPITAL:
                print(f"⚠️  Available balance < configured capital ₹{config.TOTAL_CAPITAL}. "
                      f"Running in PAPER mode.")
                config.PAPER_TRADE = True
        else:
            print("⚠️  Could not fetch funds. Check credentials.")

    # ── Morning Scan ──────────────────────────────────────
    def morning_scan(self):
        if not is_market_open():
            print("⚠️  Market not open yet.")
            return

        print(f"\n☀️  MORNING SCAN — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        signals = self.screener.run_full_scan()

        # Check daily loss limit
        if self.daily_pnl <= -(config.TOTAL_CAPITAL * config.DAILY_LOSS_LIMIT):
            print(f"🛑  Daily loss limit hit (₹{self.daily_pnl:.2f}). No new trades today.")
            return

        # Auto-place top intraday signals
        open_count = len(self.orders.open_orders)
        for sig in signals["intraday"][:config.MAX_OPEN_TRADES - open_count]:
            print(f"\n🎯  Placing intraday entry: {sig.symbol}")
            self.orders.place_entry(sig, trade_type="intraday")

        # Place options signals
        for opt in signals["options"][:1]:
            print(f"\n📈  Placing options entry: {opt.get('symbol')}")
            self.orders.place_options_order(opt)

    # ── Midday Check ──────────────────────────────────────
    def midday_check(self):
        if not is_intraday_window():
            return

        print(f"\n🔄  MIDDAY CHECK — {datetime.now().strftime('%H:%M')}")

        # Check open positions against live prices
        open_syms = list(self.orders.open_orders.keys())
        if not open_syms:
            print("  No open positions.")
            # Look for new opportunities
            signals = self.screener.scan_equities(
                config.NSE_EQUITY_WATCHLIST[:10],
                interval=config.INTRADAY_INTERVAL,
                days=5,
                segment="intraday"
            )
            for sig in signals[:1]:
                if len(self.orders.open_orders) < config.MAX_OPEN_TRADES:
                    self.orders.place_entry(sig, trade_type="intraday")
            return

        quotes = self.feed.get_quote(open_syms)
        for sym, trade in list(self.orders.open_orders.items()):
            ltp = quotes.get(sym, {}).get("ltp", 0)
            if not ltp:
                continue

            # Check SL hit
            if trade["signal"] == "LONG" and ltp <= trade["stop_loss"]:
                self.orders.exit_position(sym, ltp, reason="SL Hit")
            elif trade["signal"] == "SHORT" and ltp >= trade["stop_loss"]:
                self.orders.exit_position(sym, ltp, reason="SL Hit")
            # Check target hit
            elif trade["signal"] == "LONG" and ltp >= trade["target"]:
                self.orders.exit_position(sym, ltp, reason="Target Hit")
            elif trade["signal"] == "SHORT" and ltp <= trade["target"]:
                self.orders.exit_position(sym, ltp, reason="Target Hit")
            else:
                pnl = (ltp - trade["entry"]) * trade["qty"]
                print(f"  {sym}: LTP ₹{ltp} | Unrealised P&L: ₹{pnl:+.2f}")

    # ── Swing Scan (runs daily at 15:45 after close) ──────
    def swing_scan(self):
        print(f"\n📅  SWING SCAN — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        signals = self.screener.scan_equities(
            config.NSE_EQUITY_WATCHLIST + config.BSE_EQUITY_WATCHLIST,
            interval="D",
            days=60,
            segment="swing"
        )
        signals += self.screener.scan_commodities()
        signals.sort(key=lambda s: s.strength, reverse=True)

        print(f"\n📋  Top 5 Swing/Commodity Picks for Tomorrow:")
        for s in signals[:5]:
            print(f"\n{s}")

        # Auto-place top swing trade if capital allows
        for sig in signals[:1]:
            if sig.strength >= 65:
                print(f"\n✅  Auto-placing swing entry: {sig.symbol}")
                self.orders.place_entry(sig, trade_type="swing")

    # ── Intraday Square-Off ───────────────────────────────
    def square_off_intraday(self):
        print(f"\n🔔  SQUARING OFF INTRADAY POSITIONS — {datetime.now().strftime('%H:%M')}")
        if not self.orders.open_orders:
            print("  Nothing to square off.")
            return

        open_syms = [s for s, t in self.orders.open_orders.items()
                     if t.get("trade_type") == "intraday"]
        if open_syms:
            quotes = self.feed.get_quote(open_syms)
            for sym in open_syms:
                ltp = quotes.get(sym, {}).get("ltp", 0) or 0
                self.orders.exit_position(sym, ltp, reason="EOD Square-Off")

        if not config.PAPER_TRADE:
            # Also call Fyers API to close all MIS positions
            try:
                self.client.exit_positions(data={"id": "all"})
                print("  ✅ All MIS positions squared off via API.")
            except Exception as e:
                print(f"  ⚠️ API square-off error: {e}")

    # ── EOD Report ────────────────────────────────────────
    def eod_report(self):
        print(f"\n📊  END OF DAY REPORT — {datetime.now().strftime('%Y-%m-%d')}")
        summary = self.orders.pnl_summary()
        self.daily_pnl = summary["total_pnl"]

    # ── Run Scheduler ─────────────────────────────────────
    def run(self):
        print(f"\n{'='*55}")
        print(f"  MODE: {'📝 PAPER TRADE' if config.PAPER_TRADE else '💰 LIVE TRADE ⚠️'}")
        print(f"  Capital: ₹{config.TOTAL_CAPITAL:,}")
        print(f"  Max Risk/Trade: ₹{config.TOTAL_CAPITAL * config.MAX_RISK_PER_TRADE:.0f}")
        print(f"  Strategy: Momentum Breakout ({config.BREAKOUT_LOOKBACK}-day)")
        print(f"{'='*55}\n")

        # Schedule jobs (IST)
        schedule.every().day.at("09:20").do(self.morning_scan)
        schedule.every().day.at("11:00").do(self.midday_check)
        schedule.every().day.at("13:00").do(self.midday_check)
        schedule.every().day.at("14:00").do(self.midday_check)
        schedule.every().day.at("15:10").do(self.square_off_intraday)
        schedule.every().day.at("15:45").do(self.swing_scan)
        schedule.every().day.at("15:55").do(self.eod_report)

        # Also check positions every 5 min during market hours
        schedule.every(5).minutes.do(self.midday_check)

        print("⏳  Scheduler started. Waiting for market hours...")
        market_open_countdown()

        while True:
            schedule.run_pending()
            time.sleep(30)


# ── CLI Entry Point ───────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Fyers Momentum Trading Bot")
    parser.add_argument("--scan-only", action="store_true", help="Only scan, no orders")
    parser.add_argument("--mode", choices=["paper", "live"], default="paper",
                        help="Trading mode (default: paper)")
    parser.add_argument("--swing", action="store_true", help="Run swing scan only")
    args = parser.parse_args()

    if args.mode == "live":
        confirm = input("⚠️  LIVE trading mode. Type YES to confirm: ")
        if confirm.strip() != "YES":
            print("Aborted.")
            sys.exit(0)
        config.PAPER_TRADE = False
    else:
        config.PAPER_TRADE = True

    bot = TradingBot()

    if args.scan_only:
        bot.screener.run_full_scan()
    elif args.swing:
        bot.swing_scan()
    else:
        bot.run()


if __name__ == "__main__":
    main()

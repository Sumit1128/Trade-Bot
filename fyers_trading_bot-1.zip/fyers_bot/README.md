# 🤖 Fyers Momentum Trading Bot

A fully automated trading bot for Indian markets using the **Fyers API v3**.
Designed for ₹5,000 minimum capital with strict risk management.

---

## 📁 Project Structure

```
fyers_bot/
├── config.py         ← 🔧 All settings, credentials, watchlists
├── auth.py           ← 🔐 OAuth2 login + token caching
├── data_feed.py      ← 📊 Historical candles, live quotes, options chain
├── strategy.py       ← 🧠 Momentum/Breakout signals + indicators
├── screener.py       ← 🔍 Multi-segment market scanner
├── order_manager.py  ← 📋 Order placement (paper + live)
├── main.py           ← 🚀 Bot orchestrator + scheduler
└── requirements.txt
```

---

## ⚙️ Setup

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Create Fyers API App
1. Go to [https://myapi.fyers.in](https://myapi.fyers.in)
2. Create a new app → get **App ID** and **Secret Key**
3. Set Redirect URI to `https://127.0.0.1`

### 3. Configure `config.py`
```python
FYERS_CLIENT_ID  = "YOUR_APP_ID-100"
FYERS_SECRET_KEY = "YOUR_SECRET_KEY"
PAPER_TRADE      = True   # Start with True!
TOTAL_CAPITAL    = 5000
```

---

## 🚀 Usage

```bash
# Scan markets only (no orders placed)
python main.py --scan-only

# Run swing/commodity scan
python main.py --swing

# Full paper trading bot (auto-trades simulated)
python main.py --mode paper

# ⚠️ LIVE trading (real money — test thoroughly first!)
python main.py --mode live
```

---

## 📈 Strategy: Momentum Breakout

A signal fires when **ALL** these conditions align:

| Condition | Long (Buy) | Short (Sell) |
|-----------|-----------|-------------|
| Price | Breaks above N-day high | Breaks below N-day low |
| RSI(14) | > 55 | < 45 |
| EMA | 9 EMA > 21 EMA | 9 EMA < 21 EMA |
| Volume | ≥ 1.8× average | ≥ 1.8× average |

**Risk Management:**
- Stop Loss = Entry ± (1.5 × ATR)
- Target = Entry ± (2 × Risk) — 1:2 R/R minimum
- Max 2% capital at risk per trade = ₹100
- Max 3 concurrent open trades
- Daily loss limit: 5% of capital = ₹250

---

## 💰 Capital Allocation (₹5,000)

| Segment | Max per Trade | Notes |
|---------|-------------|-------|
| NSE/BSE Equity | ₹1,500 | Buy low-priced stocks (< ₹500/share) |
| MCX Commodities | ₹1,500 | Gold Mini, Silver Micro, Crude Oil |
| Index Options | ₹1,500 | FINNIFTY weekly (lot size 40) |
| Reserve | ₹500 | Emergency buffer |

> **Tip:** FINNIFTY weekly options with ₹50–₹80 premium = ₹2,000–₹3,200 per lot.
> Best fit for ₹5,000 capital in F&O.

---

## 🗓️ Bot Schedule (IST)

| Time | Action |
|------|--------|
| 09:20 | Morning scan → place intraday entries |
| 11:00 | Check positions, add mid-session trades |
| 13:00 | Afternoon check + momentum re-scan |
| 14:00 | Final intraday position review |
| 15:10 | **Square off all intraday (MIS) positions** |
| 15:45 | Swing/Commodity scan for next day |
| 15:55 | End-of-day P&L report |

---

## ⚠️ Disclaimers

1. **Always paper trade first** — run `--mode paper` for at least 2 weeks.
2. This bot is for **educational and personal use only**.
3. Trading involves **substantial risk of loss**.
4. The authors are not SEBI-registered advisors.
5. Past performance does not guarantee future results.
6. Options trading can result in **total loss of premium paid**.

---

## 🐛 Troubleshooting

| Error | Fix |
|-------|-----|
| `fyers_apiv3 not found` | `pip install fyers-apiv3` |
| `auth_code not found` | Paste the full redirect URL after login |
| `Token expired` | Delete `fyers_token.json` and re-run |
| No signals found | Market may be ranging — wait for breakout |
| `Available balance < ₹5000` | Bot auto-switches to paper mode |

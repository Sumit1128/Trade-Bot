# ============================================================
#  gui_login.py — Fyers OAuth GUI with Auto URL Capture
# ============================================================
"""
Replaces the terminal copy-paste login with:
  1. A local HTTP server on port 8080 that auto-catches the redirect
  2. A Tkinter GUI showing login status, token info, and fund balance
  3. Auto-launches browser → waits for redirect → saves token silently

Run standalone:  python gui_login.py
Or imported by:  auth.py (when USE_GUI = True in config.py)
"""

import json
import os
import sys
import threading
import webbrowser
from datetime import date, datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse
import tkinter as tk
from tkinter import ttk, messagebox, font as tkfont

# ── Graceful SDK import ───────────────────────────────────
try:
    from fyers_apiv3 import fyersModel
    SDK_AVAILABLE = True
except ImportError:
    SDK_AVAILABLE = False

import config

# ─────────────────────────────────────────────────────────
#  Colour Palette
# ─────────────────────────────────────────────────────────
BG        = "#0D1117"   # Near black
CARD      = "#161B22"   # Dark card
BORDER    = "#30363D"   # Subtle border
ACCENT    = "#238636"   # Fyers green
ACCENT_H  = "#2EA043"   # Hover green
RED       = "#DA3633"
YELLOW    = "#D29922"
TEXT      = "#E6EDF3"
MUTED     = "#8B949E"
WHITE     = "#FFFFFF"


# ─────────────────────────────────────────────────────────
#  Local OAuth Redirect Catcher
# ─────────────────────────────────────────────────────────
_captured_auth_code: str | None = None
_oauth_server: HTTPServer | None = None


class _RedirectHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        global _captured_auth_code
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        code   = params.get("auth_code", [None])[0]

        if code:
            _captured_auth_code = code
            body = b"""<html><body style='background:#0D1117;color:#E6EDF3;
                font-family:sans-serif;text-align:center;padding-top:80px'>
                <h2 style='color:#238636'>&#10003; Login Successful!</h2>
                <p>You can close this tab and return to the bot.</p></body></html>"""
            self.send_response(200)
        else:
            body = b"""<html><body style='background:#0D1117;color:#DA3633;
                font-family:sans-serif;text-align:center;padding-top:80px'>
                <h2>&#10007; Auth code not found</h2>
                <p>Please try again.</p></body></html>"""
            self.send_response(400)

        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass  # Suppress HTTP logs


def _start_redirect_server(port: int = 8080):
    global _oauth_server
    _oauth_server = HTTPServer(("127.0.0.1", port), _RedirectHandler)
    _oauth_server.serve_forever()


def _stop_redirect_server():
    global _oauth_server
    if _oauth_server:
        threading.Thread(target=_oauth_server.shutdown, daemon=True).start()


# ─────────────────────────────────────────────────────────
#  Token Helpers
# ─────────────────────────────────────────────────────────
def _load_cached_token() -> dict | None:
    if not os.path.exists(config.TOKEN_FILE):
        return None
    try:
        with open(config.TOKEN_FILE) as f:
            data = json.load(f)
        if data.get("date") == str(date.today()):
            return data
    except Exception:
        pass
    return None


def _save_token(token: str, client_id: str, secret: str):
    with open(config.TOKEN_FILE, "w") as f:
        json.dump({
            "access_token": token,
            "date": str(date.today()),
            "client_id": client_id,
        }, f)


# ─────────────────────────────────────────────────────────
#  Main GUI Class
# ─────────────────────────────────────────────────────────
class FyersLoginGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Fyers Trading Bot — Login")
        self.root.geometry("520x640")
        self.root.resizable(False, False)
        self.root.configure(bg=BG)

        # Centre window
        self.root.eval("tk::PlaceWindow . center")

        self._access_token: str | None = None
        self._fyers_client = None
        self._session      = None

        self._build_ui()
        self._check_cached_token()

    # ── UI Construction ───────────────────────────────────
    def _build_ui(self):
        # ── Header ───────────────────────────────────────
        hdr = tk.Frame(self.root, bg=CARD, pady=18)
        hdr.pack(fill="x")

        logo_lbl = tk.Label(hdr, text="📈  Fyers Trading Bot",
                            bg=CARD, fg=WHITE,
                            font=("Segoe UI", 17, "bold"))
        logo_lbl.pack()
        tk.Label(hdr, text="Momentum Breakout Strategy  •  ₹5,000 Capital",
                 bg=CARD, fg=MUTED, font=("Segoe UI", 9)).pack()

        # ── Credentials Card ─────────────────────────────
        self._cred_card = self._card(self.root, "🔑  API Credentials")

        self._app_id_var = tk.StringVar(value=config.FYERS_CLIENT_ID
                                        if config.FYERS_CLIENT_ID != "YOUR_APP_ID-100" else "")
        self._secret_var = tk.StringVar(value=config.FYERS_SECRET_KEY
                                        if config.FYERS_SECRET_KEY != "YOUR_SECRET_KEY" else "")

        self._field(self._cred_card, "App ID (e.g. XY12345-100)", self._app_id_var)
        self._field(self._cred_card, "Secret Key", self._secret_var, show="•")

        # Save creds checkbox
        self._save_creds = tk.BooleanVar(value=True)
        tk.Checkbutton(self._cred_card, text="Save credentials to config.py",
                       variable=self._save_creds,
                       bg=CARD, fg=MUTED, selectcolor=BG,
                       activebackground=CARD, activeforeground=TEXT,
                       font=("Segoe UI", 9)).pack(anchor="w", padx=4, pady=(4, 0))

        # ── OAuth Card ────────────────────────────────────
        oauth_card = self._card(self.root, "🌐  Login via Browser")

        tk.Label(oauth_card,
                 text="Click below → your browser opens → log in → bot connects automatically.",
                 bg=CARD, fg=MUTED, font=("Segoe UI", 9),
                 wraplength=420, justify="left").pack(anchor="w", padx=4, pady=(0, 10))

        self._login_btn = tk.Button(
            oauth_card,
            text="  🔐  Connect Fyers Account",
            command=self._start_login,
            bg=ACCENT, fg=WHITE,
            font=("Segoe UI", 11, "bold"),
            relief="flat", bd=0,
            padx=16, pady=10,
            cursor="hand2",
            activebackground=ACCENT_H, activeforeground=WHITE,
        )
        self._login_btn.pack(fill="x", padx=4)

        # ── Status Card ───────────────────────────────────
        status_card = self._card(self.root, "📡  Connection Status")

        self._status_dot = tk.Label(status_card, text="⬤", fg=YELLOW, bg=CARD,
                                    font=("Segoe UI", 12))
        self._status_dot.pack(side="left", padx=(0, 8))

        self._status_lbl = tk.Label(status_card, text="Not connected",
                                    bg=CARD, fg=MUTED,
                                    font=("Segoe UI", 10))
        self._status_lbl.pack(side="left")

        # ── Info Grid ─────────────────────────────────────
        info_card = self._card(self.root, "💰  Account Info")
        self._info_frame = info_card

        self._info_rows = {}
        for label in ["Client ID", "Token Date", "Available Funds", "Trading Mode"]:
            row = tk.Frame(info_card, bg=CARD)
            row.pack(fill="x", pady=2)
            tk.Label(row, text=label + ":", bg=CARD, fg=MUTED,
                     font=("Segoe UI", 9), width=16, anchor="w").pack(side="left")
            val = tk.Label(row, text="—", bg=CARD, fg=TEXT,
                           font=("Segoe UI", 9, "bold"), anchor="w")
            val.pack(side="left")
            self._info_rows[label] = val

        # ── Launch Button ─────────────────────────────────
        self._launch_btn = tk.Button(
            self.root,
            text="  🚀  Launch Trading Bot",
            command=self._launch_bot,
            bg="#1C2128", fg=MUTED,
            font=("Segoe UI", 11, "bold"),
            relief="flat", bd=0,
            padx=16, pady=12,
            cursor="hand2",
            state="disabled",
        )
        self._launch_btn.pack(fill="x", padx=20, pady=(4, 4))

        # Scan-only button
        self._scan_btn = tk.Button(
            self.root,
            text="🔍  Scan Only (no orders)",
            command=self._scan_only,
            bg="#1C2128", fg=MUTED,
            font=("Segoe UI", 9),
            relief="flat", bd=0, padx=8, pady=6,
            cursor="hand2", state="disabled",
        )
        self._scan_btn.pack(fill="x", padx=20, pady=(0, 12))

        # ── Footer ────────────────────────────────────────
        tk.Label(self.root,
                 text="⚠️  Always paper trade before going live  •  PAPER MODE active",
                 bg=BG, fg=YELLOW, font=("Segoe UI", 8)).pack(pady=(0, 8))

    # ── UI Helpers ────────────────────────────────────────
    def _card(self, parent, title: str) -> tk.Frame:
        outer = tk.Frame(parent, bg=BORDER, pady=1)
        outer.pack(fill="x", padx=20, pady=6)
        inner = tk.Frame(outer, bg=CARD, padx=14, pady=12)
        inner.pack(fill="both")
        tk.Label(inner, text=title, bg=CARD, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", pady=(0, 6))
        return inner

    def _field(self, parent, label: str, var: tk.StringVar, show: str = ""):
        tk.Label(parent, text=label, bg=CARD, fg=MUTED,
                 font=("Segoe UI", 8)).pack(anchor="w")
        entry = tk.Entry(parent, textvariable=var, show=show,
                         bg="#0D1117", fg=TEXT, insertbackground=TEXT,
                         relief="flat", bd=0, font=("Consolas", 10),
                         highlightthickness=1, highlightbackground=BORDER,
                         highlightcolor=ACCENT)
        entry.pack(fill="x", pady=(2, 8), ipady=6, padx=2)
        return entry

    def _set_status(self, text: str, color: str = MUTED):
        self._status_dot.config(fg=color)
        self._status_lbl.config(text=text, fg=color)

    def _set_info(self, key: str, value: str, color: str = TEXT):
        if key in self._info_rows:
            self._info_rows[key].config(text=value, fg=color)

    # ── Check Cached Token ────────────────────────────────
    def _check_cached_token(self):
        cached = _load_cached_token()
        if cached:
            self._access_token = cached["access_token"]
            self._set_status("✅  Connected (cached token)", ACCENT)
            self._set_info("Client ID", cached.get("client_id", config.FYERS_CLIENT_ID))
            self._set_info("Token Date", cached.get("date", "today"), ACCENT)
            self._set_info("Trading Mode",
                           "📝 Paper Trade" if config.PAPER_TRADE else "💰 LIVE",
                           YELLOW if config.PAPER_TRADE else RED)
            self._enable_launch()
            threading.Thread(target=self._fetch_funds, daemon=True).start()

    # ── Login Flow ────────────────────────────────────────
    def _start_login(self):
        app_id = self._app_id_var.get().strip()
        secret = self._secret_var.get().strip()

        if not app_id or not secret:
            messagebox.showerror("Missing Credentials",
                                 "Please enter your Fyers App ID and Secret Key.")
            return
        if not SDK_AVAILABLE:
            messagebox.showerror("SDK Missing",
                                 "Run:  pip install fyers-apiv3\nthen restart.")
            return

        # Optionally persist to config.py
        if self._save_creds.get():
            self._persist_credentials(app_id, secret)

        config.FYERS_CLIENT_ID  = app_id
        config.FYERS_SECRET_KEY = secret

        self._login_btn.config(text="  ⏳  Waiting for browser login...", state="disabled")
        self._set_status("⏳  Opening browser...", YELLOW)

        threading.Thread(target=self._oauth_thread, daemon=True).start()

    def _oauth_thread(self):
        global _captured_auth_code
        _captured_auth_code = None

        # Start local redirect server
        server_thread = threading.Thread(target=_start_redirect_server, args=(8080,), daemon=True)
        server_thread.start()

        try:
            self._session = fyersModel.SessionModel(
                client_id=config.FYERS_CLIENT_ID,
                secret_key=config.FYERS_SECRET_KEY,
                redirect_uri="http://127.0.0.1:8080",
                response_type="code",
                grant_type="authorization_code",
                state="trading_bot",
            )
            auth_url = self._session.generate_authcode()
            self.root.after(0, self._set_status, "🌐  Browser opened — please log in...", YELLOW)
            webbrowser.open(auth_url)

            # Wait up to 120 seconds for redirect
            for _ in range(240):
                if _captured_auth_code:
                    break
                threading.Event().wait(0.5)

            _stop_redirect_server()

            if not _captured_auth_code:
                self.root.after(0, self._on_login_failed, "Login timed out (2 min). Try again.")
                return

            self._session.set_token(_captured_auth_code)
            token_resp = self._session.generate_token()

            if token_resp.get("s") != "ok":
                self.root.after(0, self._on_login_failed,
                                f"Token error: {token_resp.get('message', token_resp)}")
                return

            token = token_resp["access_token"]
            _save_token(token, config.FYERS_CLIENT_ID, config.FYERS_SECRET_KEY)
            self._access_token = token
            self.root.after(0, self._on_login_success)

        except Exception as e:
            _stop_redirect_server()
            self.root.after(0, self._on_login_failed, str(e))

    def _on_login_success(self):
        self._set_status("✅  Connected successfully!", ACCENT)
        self._login_btn.config(text="  ✅  Connected — Reconnect", state="normal",
                               bg="#1C2128", fg=ACCENT)
        self._set_info("Client ID", config.FYERS_CLIENT_ID)
        self._set_info("Token Date", str(date.today()), ACCENT)
        self._set_info("Trading Mode",
                       "📝 Paper Trade" if config.PAPER_TRADE else "💰 LIVE",
                       YELLOW if config.PAPER_TRADE else RED)
        self._enable_launch()
        threading.Thread(target=self._fetch_funds, daemon=True).start()

    def _on_login_failed(self, reason: str):
        self._set_status(f"❌  Login failed", RED)
        self._login_btn.config(text="  🔐  Retry Login", state="normal")
        messagebox.showerror("Login Failed", reason)

    # ── Fetch Live Funds ──────────────────────────────────
    def _fetch_funds(self):
        if not self._access_token:
            return
        try:
            client = fyersModel.FyersModel(
                client_id=config.FYERS_CLIENT_ID,
                token=self._access_token,
                is_async=False, log_path=""
            )
            self._fyers_client = client
            resp = client.funds()
            if resp.get("s") == "ok":
                funds = {i["title"]: i["equityAmount"] for i in resp.get("fund_limit", [])}
                avail = (funds.get("Available Balance")
                         or funds.get("Total Balance")
                         or funds.get("Net Balance", 0))
                color = ACCENT if float(avail) >= config.TOTAL_CAPITAL else RED
                self.root.after(0, self._set_info, "Available Funds",
                                f"₹{float(avail):,.2f}", color)
                if float(avail) < config.TOTAL_CAPITAL:
                    self.root.after(0, self._set_info, "Trading Mode",
                                   "📝 Paper (low balance)", YELLOW)
        except Exception as e:
            self.root.after(0, self._set_info, "Available Funds", f"Error: {e}", RED)

    # ── Enable Launch Buttons ─────────────────────────────
    def _enable_launch(self):
        self._launch_btn.config(state="normal", bg=ACCENT, fg=WHITE)
        self._scan_btn.config(state="normal", bg="#1C2128", fg=TEXT)

    # ── Launch Actions ────────────────────────────────────
    def _launch_bot(self):
        if not self._access_token:
            messagebox.showwarning("Not Connected", "Please connect your Fyers account first.")
            return
        self.root.destroy()
        # Import here to avoid circular on first run
        import subprocess, sys
        subprocess.Popen([sys.executable, "main.py", "--mode", "paper"])

    def _scan_only(self):
        if not self._access_token:
            messagebox.showwarning("Not Connected", "Please connect your Fyers account first.")
            return
        self.root.destroy()
        import subprocess, sys
        subprocess.Popen([sys.executable, "main.py", "--scan-only"])

    # ── Persist Credentials ───────────────────────────────
    def _persist_credentials(self, app_id: str, secret: str):
        """Overwrite App ID and Secret in config.py so they load on next run."""
        try:
            with open("config.py", "r") as f:
                content = f.read()
            content = content.replace(
                content[content.find("FYERS_CLIENT_ID"):content.find("\n", content.find("FYERS_CLIENT_ID"))],
                f'FYERS_CLIENT_ID   = "{app_id}"'
            )
            content = content.replace(
                content[content.find("FYERS_SECRET_KEY"):content.find("\n", content.find("FYERS_SECRET_KEY"))],
                f'FYERS_SECRET_KEY  = "{secret}"'
            )
            with open("config.py", "w") as f:
                f.write(content)
        except Exception:
            pass  # Non-critical

    # ── Run ───────────────────────────────────────────────
    def run(self) -> str | None:
        """Launch GUI and return access token when done."""
        self.root.mainloop()
        return self._access_token


# ─────────────────────────────────────────────────────────
#  Public helper used by auth.py
# ─────────────────────────────────────────────────────────
def gui_login() -> str:
    """Open the GUI login window and return the access token."""
    app = FyersLoginGUI()
    token = app.run()
    if not token:
        raise RuntimeError("Login cancelled or failed.")
    return token


# ─────────────────────────────────────────────────────────
#  Standalone run
# ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("Launching Fyers Login GUI...")
    token = gui_login()
    print(f"✅  Token obtained: {token[:30]}...")

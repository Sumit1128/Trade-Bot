# ============================================================
#  strategy.py — Momentum / Breakout Strategy Engine
# ============================================================
"""
Strategy Logic:
─────────────────────────────────────────────────────────────
LONG BREAKOUT Signal (all conditions must be True):
  1. Close breaks above N-day high (configurable)
  2. RSI(14) > 55 (momentum confirmation)
  3. EMA(9) > EMA(21) (trend confirmation)
  4. Volume >= 1.8x 20-day avg volume (participation)
  5. ATR-based stop-loss placed at 1.5x ATR below entry
  6. Target = Entry + 2x risk (1:2 R/R)

SHORT BREAKDOWN Signal (inverse of above):
  1. Close breaks below N-day low
  2. RSI(14) < 45
  3. EMA(9) < EMA(21)
  4. Volume >= 1.8x avg

The screener runs this on every symbol and returns ranked signals.
─────────────────────────────────────────────────────────────
"""

import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum

import config


class SignalType(Enum):
    LONG  = "LONG"
    SHORT = "SHORT"
    NONE  = "NONE"


@dataclass
class TradeSignal:
    symbol:       str
    signal:       SignalType
    entry:        float
    stop_loss:    float
    target:       float
    risk:         float           # INR per share/unit
    reward:       float           # INR per share/unit
    rr_ratio:     float           # reward/risk
    qty:          int             # Calculated quantity for capital
    total_invest: float           # qty * entry
    rsi:          float
    atr:          float
    volume_ratio: float           # current vol / avg vol
    strength:     float           # score 0-100
    segment:      str             # "equity" | "options" | "commodity" | "swing"
    notes:        str = ""

    def __repr__(self):
        arrow = "🟢 LONG" if self.signal == SignalType.LONG else "🔴 SHORT"
        return (
            f"{arrow}  {self.symbol}\n"
            f"  Entry: ₹{self.entry:.2f}  |  SL: ₹{self.stop_loss:.2f}  "
            f"|  Target: ₹{self.target:.2f}\n"
            f"  Qty: {self.qty}  |  Invest: ₹{self.total_invest:.0f}  "
            f"|  R/R: 1:{self.rr_ratio:.1f}  |  Strength: {self.strength:.0f}/100\n"
            f"  RSI: {self.rsi:.1f}  |  Vol Ratio: {self.volume_ratio:.1f}x  "
            f"|  ATR: {self.atr:.2f}  |  Notes: {self.notes}"
        )


# ── Indicator Calculations ────────────────────────────────

def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()

def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain  = delta.clip(lower=0).rolling(period).mean()
    loss  = (-delta.clip(upper=0)).rolling(period).mean()
    rs    = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    hl  = df["high"] - df["low"]
    hc  = (df["high"] - df["close"].shift()).abs()
    lc  = (df["low"]  - df["close"].shift()).abs()
    tr  = pd.concat([hl, hc, lc], axis=1).max(axis=1)
    return tr.rolling(period).mean()

def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["ema_fast"]   = ema(df["close"], config.EMA_FAST)
    df["ema_slow"]   = ema(df["close"], config.EMA_SLOW)
    df["rsi"]        = rsi(df["close"], config.RSI_PERIOD)
    df["atr"]        = atr(df, config.ATR_PERIOD)
    df["vol_avg"]    = df["volume"].rolling(20).mean()
    df["vol_ratio"]  = df["volume"] / df["vol_avg"].replace(0, np.nan)
    df["high_n"]     = df["high"].rolling(config.BREAKOUT_LOOKBACK).max().shift(1)
    df["low_n"]      = df["low"].rolling(config.BREAKOUT_LOOKBACK).min().shift(1)
    return df


# ── Signal Scoring ────────────────────────────────────────

def _score_signal(
    rsi_val: float,
    vol_ratio: float,
    rr: float,
    ema_gap_pct: float,
    signal: SignalType
) -> float:
    """Returns a strength score 0–100."""
    score = 0
    # RSI contribution (0-30)
    if signal == SignalType.LONG:
        score += min(30, max(0, (rsi_val - 50) * 1.5))
    else:
        score += min(30, max(0, (50 - rsi_val) * 1.5))
    # Volume (0-30)
    score += min(30, (vol_ratio - 1) * 15)
    # R/R ratio (0-20)
    score += min(20, rr * 5)
    # EMA gap (0-20)
    score += min(20, abs(ema_gap_pct) * 200)
    return round(min(100, max(0, score)), 1)


# ── Main Strategy Function ────────────────────────────────

def evaluate_signal(
    symbol: str,
    df: pd.DataFrame,
    capital: float = config.TOTAL_CAPITAL,
    segment: str = "equity"
) -> Optional[TradeSignal]:
    """
    Run momentum/breakout strategy on a DataFrame with indicators.
    Returns a TradeSignal if conditions met, else None.
    """
    if df is None or len(df) < config.BREAKOUT_LOOKBACK + 5:
        return None

    df = add_indicators(df)
    row = df.iloc[-1]   # Latest candle

    close     = row["close"]
    high_n    = row["high_n"]   # N-day high (excluding current)
    low_n     = row["low_n"]    # N-day low
    rsi_val   = row["rsi"]
    atr_val   = row["atr"]
    vol_ratio = row["vol_ratio"] if not np.isnan(row["vol_ratio"]) else 0
    ema_fast  = row["ema_fast"]
    ema_slow  = row["ema_slow"]

    if np.isnan(high_n) or np.isnan(atr_val) or atr_val == 0:
        return None

    ema_gap_pct = (ema_fast - ema_slow) / ema_slow

    # ── LONG Breakout ─────────────────────────────────────
    long_conditions = (
        close > high_n and                                # Price breakout
        rsi_val > config.RSI_BREAKOUT_MIN and             # Momentum
        ema_fast > ema_slow and                           # Trend
        vol_ratio >= config.VOLUME_SURGE_FACTOR           # Volume
    )

    # ── SHORT Breakdown ───────────────────────────────────
    short_conditions = (
        close < low_n and
        rsi_val < (100 - config.RSI_BREAKOUT_MIN) and
        ema_fast < ema_slow and
        vol_ratio >= config.VOLUME_SURGE_FACTOR
    )

    if not (long_conditions or short_conditions):
        return None

    signal = SignalType.LONG if long_conditions else SignalType.SHORT

    # ── Risk Calculation ──────────────────────────────────
    if signal == SignalType.LONG:
        stop_loss = close - (config.ATR_STOP_MULTIPLIER * atr_val)
        target    = close + (config.RISK_REWARD_RATIO * (close - stop_loss))
    else:
        stop_loss = close + (config.ATR_STOP_MULTIPLIER * atr_val)
        target    = close - (config.RISK_REWARD_RATIO * (stop_loss - close))

    risk_per_unit   = abs(close - stop_loss)
    reward_per_unit = abs(target - close)
    rr_ratio        = reward_per_unit / risk_per_unit if risk_per_unit > 0 else 0

    # ── Position Sizing (risk-based) ──────────────────────
    max_loss_inr   = capital * config.MAX_RISK_PER_TRADE          # ₹100
    max_invest_inr = capital * config.MAX_POSITION_SIZE            # ₹1500
    qty_by_risk    = int(max_loss_inr / risk_per_unit) if risk_per_unit > 0 else 1
    qty_by_capital = int(max_invest_inr / close) if close > 0 else 1
    qty            = max(1, min(qty_by_risk, qty_by_capital))
    total_invest   = qty * close

    # Skip if even 1 unit exceeds budget
    if close > max_invest_inr:
        return None

    strength = _score_signal(rsi_val, vol_ratio, rr_ratio, ema_gap_pct, signal)

    # Build notes
    notes_parts = []
    if vol_ratio > 3:
        notes_parts.append(f"Very high volume ({vol_ratio:.1f}x)")
    if abs(ema_gap_pct) > 0.01:
        notes_parts.append("Strong trend")
    if rsi_val > 70 and signal == SignalType.LONG:
        notes_parts.append("⚠️ RSI overbought — tighten SL")
    if rsi_val < 30 and signal == SignalType.SHORT:
        notes_parts.append("⚠️ RSI oversold — tighten SL")
    notes = ", ".join(notes_parts) if notes_parts else "Clean breakout"

    return TradeSignal(
        symbol=symbol, signal=signal,
        entry=round(close, 2),
        stop_loss=round(stop_loss, 2),
        target=round(target, 2),
        risk=round(risk_per_unit, 2),
        reward=round(reward_per_unit, 2),
        rr_ratio=round(rr_ratio, 2),
        qty=qty,
        total_invest=round(total_invest, 2),
        rsi=round(rsi_val, 2),
        atr=round(atr_val, 2),
        volume_ratio=round(vol_ratio, 2),
        strength=strength,
        segment=segment,
        notes=notes,
    )


# ── Options Strategy ──────────────────────────────────────

def get_options_signal(
    chain: dict,
    underlying_signal: SignalType,
    capital: float = config.TOTAL_CAPITAL
) -> Optional[dict]:
    """
    Given an options chain and direction signal, find the best
    OTM option to buy that fits within capital constraints.
    Returns dict with symbol, strike, type, premium, qty.
    """
    if chain is None or underlying_signal == SignalType.NONE:
        return None

    opt_type = "CE" if underlying_signal == SignalType.LONG else "PE"

    try:
        options = chain.get("options_chain", [])
        # Filter by option type and affordable premium
        candidates = [
            o for o in options
            if o.get("option_type") == opt_type
            and 0 < o.get("ltp", 999) <= config.OPTIONS_MAX_PREMIUM
        ]
        if not candidates:
            return None

        # Sort: prefer higher OI (liquidity) and delta
        candidates.sort(key=lambda x: x.get("oi", 0), reverse=True)
        best = candidates[0]

        premium   = best["ltp"]
        lot_size  = best.get("lot_size", 1)
        cost_1lot = premium * lot_size

        if cost_1lot > capital * config.MAX_POSITION_SIZE:
            return None

        lots = max(1, int((capital * config.MAX_POSITION_SIZE) / cost_1lot))

        return {
            "symbol":    best.get("symbol"),
            "strike":    best.get("strike_price"),
            "type":      opt_type,
            "premium":   premium,
            "lot_size":  lot_size,
            "lots":      lots,
            "total_cost": round(lots * cost_1lot, 2),
            "max_loss":   round(lots * cost_1lot, 2),
            "notes":     f"Buy {lots} lot(s) @ ₹{premium} | OI: {best.get('oi',0):,}",
        }
    except Exception as e:
        print(f"Options signal error: {e}")
        return None

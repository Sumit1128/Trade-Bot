# ============================================================
#  data_feed.py — Market Data via Fyers API v3
# ============================================================
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional
import time

import config


class DataFeed:
    def __init__(self, fyers_client):
        self.client = fyers_client

    # ── Historical OHLCV ──────────────────────────────────
    def get_candles(
        self,
        symbol: str,
        interval: str = "D",
        days: int = 60
    ) -> Optional[pd.DataFrame]:
        """
        Fetch historical OHLCV candles.
        interval: "1","5","15","60" (minutes) or "D" (daily)
        Returns DataFrame with columns: datetime, open, high, low, close, volume
        """
        end_dt   = datetime.now()
        start_dt = end_dt - timedelta(days=days)

        data = {
            "symbol":       symbol,
            "resolution":   interval,
            "date_format":  "1",
            "range_from":   start_dt.strftime("%Y-%m-%d"),
            "range_to":     end_dt.strftime("%Y-%m-%d"),
            "cont_flag":    "1",
        }
        try:
            resp = self.client.history(data=data)
            if resp.get("s") != "ok":
                print(f"⚠️  Data error for {symbol}: {resp.get('message','')}")
                return None
            candles = resp["candles"]  # [[epoch, o, h, l, c, v], ...]
            df = pd.DataFrame(candles, columns=["datetime","open","high","low","close","volume"])
            df["datetime"] = pd.to_datetime(df["datetime"], unit="s")
            df = df.sort_values("datetime").reset_index(drop=True)
            return df
        except Exception as e:
            print(f"❌  Exception fetching {symbol}: {e}")
            return None

    # ── Live Quote ────────────────────────────────────────
    def get_quote(self, symbols: list[str]) -> dict:
        """
        Fetch live LTP, bid, ask for a list of symbols.
        Returns {symbol: {ltp, bid, ask, open, high, low, close, volume}}
        """
        sym_str = ",".join(symbols)
        try:
            resp = self.client.quotes(data={"symbols": sym_str})
            if resp.get("s") != "ok":
                return {}
            result = {}
            for q in resp.get("d", []):
                v = q.get("v", {})
                result[q["n"]] = {
                    "ltp":    v.get("lp", 0),
                    "open":   v.get("open_price", 0),
                    "high":   v.get("high_price", 0),
                    "low":    v.get("low_price", 0),
                    "close":  v.get("prev_close_price", 0),
                    "volume": v.get("volume", 0),
                    "bid":    v.get("bid", 0),
                    "ask":    v.get("ask", 0),
                }
            return result
        except Exception as e:
            print(f"❌  Quote error: {e}")
            return {}

    # ── Options Chain ─────────────────────────────────────
    def get_options_chain(self, underlying: str) -> Optional[dict]:
        """
        Fetch options chain for index/stock.
        e.g. underlying = "NSE:NIFTY50-INDEX"
        """
        try:
            resp = self.client.optionchain(
                data={"symbol": underlying, "strikecount": 10, "timestamp": ""}
            )
            if resp.get("s") != "ok":
                return None
            return resp
        except Exception as e:
            print(f"❌  Options chain error: {e}")
            return None

    # ── Fund Info ─────────────────────────────────────────
    def get_funds(self) -> dict:
        """Returns available margin/funds breakdown."""
        try:
            resp = self.client.funds()
            if resp.get("s") == "ok":
                fund_data = {}
                for item in resp.get("fund_limit", []):
                    fund_data[item["title"]] = item["equityAmount"]
                return fund_data
        except Exception as e:
            print(f"❌  Funds error: {e}")
        return {}

    # ── Positions ─────────────────────────────────────────
    def get_positions(self) -> list[dict]:
        try:
            resp = self.client.positions()
            return resp.get("netPositions", []) if resp.get("s") == "ok" else []
        except Exception:
            return []

    def get_holdings(self) -> list[dict]:
        try:
            resp = self.client.holdings()
            return resp.get("holdings", []) if resp.get("s") == "ok" else []
        except Exception:
            return []

# ============================================================
#  auth.py — Fyers API v3 Authentication Handler
# ============================================================
import json, os, webbrowser
from urllib.parse import urlparse, parse_qs
from datetime import date

try:
    from fyers_apiv3 import fyersModel
except ImportError:
    print("❌  Install Fyers SDK:  pip install fyers-apiv3")
    raise

import config


def _load_cached_token() -> dict | None:
    if not os.path.exists(config.TOKEN_FILE):
        return None
    try:
        with open(config.TOKEN_FILE) as f:
            data = json.load(f)
        if data.get("date") == str(date.today()):
            return data
    except Exception:
        pass
    return None


def _save_token(access_token: str):
    with open(config.TOKEN_FILE, "w") as f:
        json.dump({"access_token": access_token, "date": str(date.today())}, f)


def get_fyers_client() -> fyersModel.FyersModel:
    """
    Returns an authenticated FyersModel instance.
    1. Tries cached daily token first.
    2. Falls back to GUI login window (default).
    3. Falls back to terminal login if GUI unavailable.
    """
    cached = _load_cached_token()

    if cached:
        print("✅  Using cached Fyers token.")
        access_token = cached["access_token"]
    else:
        access_token = _fresh_login()
        _save_token(access_token)

    return fyersModel.FyersModel(
        client_id=config.FYERS_CLIENT_ID,
        token=access_token,
        is_async=False,
        log_path=""
    )


def _fresh_login() -> str:
    """Try GUI login first; fall back to terminal if no display."""
    has_display = True
    if os.name != "nt":  # Non-Windows: check for display env
        has_display = bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))

    if has_display:
        try:
            from gui_login import gui_login
            print("🖥️   Opening GUI login window...")
            return gui_login()
        except Exception as e:
            print(f"⚠️  GUI unavailable ({e}), falling back to terminal login.")

    return _terminal_login()


def _terminal_login() -> str:
    """Fallback terminal-based OAuth flow."""
    session = fyersModel.SessionModel(
        client_id=config.FYERS_CLIENT_ID,
        secret_key=config.FYERS_SECRET_KEY,
        redirect_uri=config.FYERS_REDIRECT_URI,
        response_type=config.FYERS_RESPONSE_TYPE,
        grant_type=config.FYERS_GRANT_TYPE,
        state=config.FYERS_STATE,
    )
    auth_url = session.generate_authcode()
    print(f"\n🔐  Opening browser...\n{auth_url}\n")
    webbrowser.open(auth_url)

    redirected = input("📋  Paste full redirect URL: ").strip()
    auth_code  = parse_qs(urlparse(redirected).query).get("auth_code", [None])[0]
    if not auth_code:
        raise ValueError("❌  Could not extract auth_code.")

    session.set_token(auth_code)
    resp = session.generate_token()
    if resp.get("s") != "ok":
        raise RuntimeError(f"Token error: {resp}")

    print("✅  Fyers login successful!")
    return resp["access_token"]

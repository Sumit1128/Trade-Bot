# ============================================================
#  config.py — Central Configuration for Fyers Trading Bot
# ============================================================

# ── Fyers API Credentials ──────────────────────────────────
FYERS_CLIENT_ID   = "YOUR_APP_ID-100"        # e.g. "XY12345-100"
FYERS_SECRET_KEY  = "YOUR_SECRET_KEY"
FYERS_REDIRECT_URI = "https://127.0.0.1"
FYERS_RESPONSE_TYPE = "code"
FYERS_GRANT_TYPE    = "authorization_code"
FYERS_STATE         = "trading_bot"

# Path where auth token will be cached
TOKEN_FILE = "fyers_token.json"
LOG_FILE   = "trades.log"

# ── Capital & Risk Management ──────────────────────────────
TOTAL_CAPITAL       = 5000        # INR
MAX_RISK_PER_TRADE  = 0.02        # 2% of capital = ₹100 max loss per trade
MAX_POSITION_SIZE   = 0.30        # Max 30% of capital in single trade = ₹1500
MAX_OPEN_TRADES     = 3           # Max concurrent positions
DAILY_LOSS_LIMIT    = 0.05        # Stop trading if daily loss > 5% (₹250)

# ── Strategy Parameters ────────────────────────────────────
BREAKOUT_LOOKBACK   = 20          # Days for high/low breakout detection
RSI_PERIOD          = 14
RSI_BREAKOUT_MIN    = 55          # RSI must be above this for long breakout
VOLUME_SURGE_FACTOR = 1.8         # Volume must be 1.8x avg to confirm breakout
EMA_FAST            = 9
EMA_SLOW            = 21
ATR_PERIOD          = 14
ATR_STOP_MULTIPLIER = 1.5         # Stop = Entry - 1.5 * ATR
RISK_REWARD_RATIO   = 2.0         # Target = Entry + 2 * (Entry - Stop)

# ── Intraday Settings ──────────────────────────────────────
INTRADAY_START_TIME  = "09:20"    # Don't trade in first 5 min
INTRADAY_EXIT_TIME   = "15:10"    # Square off before 3:15 PM
INTRADAY_PRODUCT     = "INTRADAY" # Fyers product code

# ── Swing / Positional Settings ───────────────────────────
SWING_HOLD_DAYS     = 5           # Max holding days for swing
SWING_PRODUCT       = "CNC"       # Cash & Carry for equity delivery

# ── Options Settings ──────────────────────────────────────
OPTIONS_MAX_PREMIUM = 80          # Max ₹80 per share premium to buy
OPTIONS_EXPIRY_TYPE = "weekly"    # weekly / monthly
OPTIONS_STRIKE_OTM  = 1          # 1 strike OTM from current price

# ── Watchlists ────────────────────────────────────────────
NSE_EQUITY_WATCHLIST = [
    "NSE:RELIANCE-EQ", "NSE:TCS-EQ", "NSE:HDFCBANK-EQ",
    "NSE:INFY-EQ",     "NSE:ICICIBANK-EQ", "NSE:SBIN-EQ",
    "NSE:AXISBANK-EQ", "NSE:BAJFINANCE-EQ","NSE:WIPRO-EQ",
    "NSE:TATAMOTORS-EQ","NSE:ADANIENT-EQ", "NSE:LT-EQ",
    "NSE:ONGC-EQ",     "NSE:POWERGRID-EQ", "NSE:NTPC-EQ",
    "NSE:TATASTEEL-EQ","NSE:JSWSTEEL-EQ",  "NSE:COALINDIA-EQ",
    "NSE:HINDALCO-EQ", "NSE:TECHM-EQ",
    # Low-price stocks suitable for ₹5000 capital
    "NSE:YESBANK-EQ",  "NSE:SUZLON-EQ",    "NSE:IDEA-EQ",
    "NSE:IRFC-EQ",     "NSE:IRCTC-EQ",
]

BSE_EQUITY_WATCHLIST = [
    "BSE:RELIANCE-A",  "BSE:TCS-A",        "BSE:HDFCBANK-A",
    "BSE:INFY-A",      "BSE:ICICIBANK-A",
]

# Commodity symbols on MCX via Fyers
COMMODITY_WATCHLIST = [
    "MCX:GOLD25APRFUT",     # Gold futures (near month)
    "MCX:GOLDM25APRFUT",    # Gold Mini (smaller lot, more accessible)
    "MCX:SILVER25MAYFUT",   # Silver futures
    "MCX:SILVERMIC25APRFUT",# Silver Micro
    "MCX:CRUDEOIL25APRFUT", # Crude Oil
]

# Index Options (FINNIFTY best for ₹5000 — smaller lot size of 40)
OPTIONS_WATCHLIST = [
    "NSE:FINNIFTY",
    "NSE:NIFTY50",
    "NSE:BANKNIFTY",
    "NSE:MIDCPNIFTY",
]

# ── Trading Mode ───────────────────────────────────────────
PAPER_TRADE   = True     # ← Set False only when ready for live trading
DEBUG_MODE    = True

# ── Candle Interval ───────────────────────────────────────
# "1"=1min "5"=5min "15"=15min "60"=1hr "D"=Daily
INTRADAY_INTERVAL = "5"   # 5-min candles for intraday
SWING_INTERVAL    = "D"   # Daily candles for swing
